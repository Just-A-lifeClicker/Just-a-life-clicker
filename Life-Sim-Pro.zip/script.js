// Game Variables
let money = 0;
let clickValue = 1;  // Base value of money per click
let fasterClickCost = 100;
let autoClickerCost = 500;
let autoClickerActive = false;
let fasterClickActive = false;
let carPurchased = false;
let housePurchased = false;

// DOM Elements
const moneyDisplay = document.getElementById('money');
const clickButton = document.getElementById('clickButton');
const buyFasterClick = document.getElementById('buyFasterClick');
const buyAutoClicker = document.getElementById('buyAutoClicker');
const messageDisplay = document.getElementById('message');
const shopCars = document.getElementById('shopCars');
const shopHouses = document.getElementById('shopHouses');
const shopGamble = document.getElementById('shopGamble');

// Car Shop Elements
const carShop = document.getElementById('carShop');
const buyCheapCar = document.getElementById('buyCheapCar');
const buyExpensiveCar = document.getElementById('buyExpensiveCar');
const closeCarShop = document.getElementById('closeCarShop');

// House Shop Elements
const houseShop = document.getElementById('houseShop');
const buySmallHouse = document.getElementById('buySmallHouse');
const buyMansion = document.getElementById('buyMansion');
const closeHouseShop = document.getElementById('closeHouseShop');

// Gambling Section Elements
const gambleSection = document.getElementById('gambleSection');
const gambleAmount = document.getElementById('gambleAmount');
const gambleButton = document.getElementById('gambleButton');
const closeGambleSection = document.getElementById('closeGambleSection');
const gambleMessage = document.getElementById('gambleMessage');

// Load saved game state from localStorage
function loadGame() {
  const savedGame = JSON.parse(localStorage.getItem('gameState'));
  if (savedGame) {
    money = savedGame.money || 0;
    clickValue = savedGame.clickValue || 1;
    fasterClickCost = savedGame.fasterClickCost || 100;
    autoClickerCost = savedGame.autoClickerCost || 500;
    autoClickerActive = savedGame.autoClickerActive || false;
    fasterClickActive = savedGame.fasterClickActive || false;
    carPurchased = savedGame.carPurchased || false;
    housePurchased = savedGame.housePurchased || false;
  }
  updateMoneyDisplay();
  checkShop();
}

// Save the game state to localStorage
function saveGame() {
  const gameState = {
    money: money,
    clickValue: clickValue,
    fasterClickCost: fasterClickCost,
    autoClickerCost: autoClickerCost,
    autoClickerActive: autoClickerActive,
    fasterClickActive: fasterClickActive,
    carPurchased: carPurchased,
    housePurchased: housePurchased,
  };
  localStorage.setItem('gameState', JSON.stringify(gameState));
}

// Function to update the money display
function updateMoneyDisplay() {
  moneyDisplay.textContent = money;
}

// Function to handle clicking and earning money
function handleClick() {
  money += clickValue;
  updateMoneyDisplay();
  checkShop();
  saveGame();
}

// Function to handle buying faster click upgrade
function buyFasterClickUpgrade() {
  if (money >= fasterClickCost) {
    money -= fasterClickCost;
    clickValue += 1;
    fasterClickActive = true;
    fasterClickCost = Math.floor(fasterClickCost * 1.5);
    messageDisplay.textContent = "You bought Faster Click!";
    updateMoneyDisplay();
    checkShop();
    saveGame();
  } else {
    messageDisplay.textContent = "You don't have enough money!";
  }
}

// Function to handle buying auto clicker upgrade
function buyAutoClickerUpgrade() {
  if (money >= autoClickerCost) {
    money -= autoClickerCost;
    autoClickerActive = true;
    messageDisplay.textContent = "You bought Auto Clicker!";
    updateMoneyDisplay();
    checkShop();
    saveGame();
  } else {
    messageDisplay.textContent = "You don't have enough money!";
  }
}

// Function to check shop items (Enable/Disable purchase buttons)
function checkShop() {
  if (money >= fasterClickCost) {
    buyFasterClick.disabled = false;
  } else {
    buyFasterClick.disabled = true;
  }

  if (money >= autoClickerCost) {
    buyAutoClicker.disabled = false;
  } else {
    buyAutoClicker.disabled = true;
  }
}

// Open the car shop
shopCars.addEventListener('click', () => {
  carShop.classList.remove('hidden');
});

// Close the car shop
closeCarShop.addEventListener('click', () => {
  carShop.classList.add('hidden');
});

// Buy a cheap car
buyCheapCar.addEventListener('click', () => {
  if (money >= 200) {
    money -= 200;
    carPurchased = true;
    messageDisplay.textContent = "You bought a Cheap Car!";
    updateMoneyDisplay();
    saveGame();
  } else {
    messageDisplay.textContent = "Not enough money for a Cheap Car!";
  }
});

// Buy an expensive car
buyExpensiveCar.addEventListener('click', () => {
  if (money >= 1000) {
    money -= 1000;
    carPurchased = true;
    messageDisplay.textContent = "You bought an Expensive Car!";
    updateMoneyDisplay();
    saveGame();
  } else {
    messageDisplay.textContent = "Not enough money for an Expensive Car!";
  }
});

// Open the house shop
shopHouses.addEventListener('click', () => {
  houseShop.classList.remove('hidden');
});

// Close the house shop
closeHouseShop.addEventListener('click', () => {
  houseShop.classList.add('hidden');
});

// Buy a small house
buySmallHouse.addEventListener('click', () => {
  if (money >= 500) {
    money -= 500;
    housePurchased = true;
    messageDisplay.textContent = "You bought a Small House!";
    updateMoneyDisplay();
    saveGame();
  } else {
    messageDisplay.textContent = "Not enough money for a Small House!";
  }
});

// Buy a mansion
buyMansion.addEventListener('click', () => {
  if (money >= 5000) {
    money -= 5000;
    housePurchased = true;
    messageDisplay.textContent = "You bought a Mansion!";
    updateMoneyDisplay();
    saveGame();
  } else {
    messageDisplay.textContent = "Not enough money for a Mansion!";
  }
});

// Open the gambling section
shopGamble.addEventListener('click', () => {
  gambleSection.classList.remove('hidden');
});

// Close gambling section
closeGambleSection.addEventListener('click', () => {
  gambleSection.classList.add('hidden');
});

// Gambling
gambleButton.addEventListener('click', () => {
  const amountToGamble = parseInt(gambleAmount.value);
  if (amountToGamble <= money) {
    money -= amountToGamble;
    if (Math.random() > 0.5) {
      money += amountToGamble * 2;
      gambleMessage.textContent = "You won! Your money doubled!";
    } else {
      gambleMessage.textContent = "You lost! Try again!";
    }
    updateMoneyDisplay();
    saveGame();
  } else {
    gambleMessage.textContent = "You don't have enough money!";
  }
});

// Click Button Event
clickButton.addEventListener('click', handleClick);

// Shop Button Events
buyFasterClick.addEventListener('click', buyFasterClickUpgrade);
buyAutoClicker.addEventListener('click', buyAutoClickerUpgrade);

// Initialize shop availability and load saved game state
loadGame();